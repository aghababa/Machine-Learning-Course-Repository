# Processing Data


```python
import numpy as np
import math
import time
import pandas as pd 
from scipy import linalg as LA
from scipy.optimize import minimize, Bounds
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

#for i in range(len(train1)):
#    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

#for i in range(len(test2)):
#    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```


```python
n = len(train)
m = len(test)
d = len(train[0]) - 1
```


```python
train.shape, test.shape, d, n
```




    ((872, 5), (500, 5), 4, 872)




```python
X = train[:,:-1]
Y = train[:,-1]
y = train[:,-1:]
```

# Part (b): Nonlinear SVM with Gaussian Kernel


```python
gamma_list = [0.1,0.5,1,5,100]
C_list = [100/873, 500/873, 700/873]
```


```python
def K(x,z,gamma):
    return(math.exp((- LA.norm(x-z)**2)/gamma))
```


```python
# Gram Matrix: Resturn a matrix whose ijth entry is exp{-||A_i-B_j||^2/gamma}
def Gram(A, B, gamma):  
    temp = np.sum(A**2,1).reshape(A.shape[0],1) + np.sum(B**2,1).reshape(1,B.shape[0])-2* A @ B.T
    return np.exp(-temp/gamma)
```


```python
Ker = [np.zeros((n,n)) for i in range(len(gamma_list))]

for k in range(len(gamma_list)):
    Ker[k] = Gram(X,X,gamma_list[k])
```


```python
SVM_kernel_dic = {}
a_dic = {}

start = time.time()
for j in range(len(gamma_list)):
    K1 = Gram(X, X, gamma_list[j])
    K2 = y*K1*y.T
    f = lambda x: 0.5 * x.T @ K2 @ x - np.sum(x) # x in place or a
    for i in range(len(C_list)):
        start = time.time()
        bounds = tuple([(0,C_list[i]) for k in range(n)])
        cons ={'type':'eq', 'fun': lambda x: x@Y}
        SVM_kernel_dic[(i,j)] = minimize(f, np.zeros(n), method='SLSQP', 
                                         bounds = bounds, constraints = cons) 
                                          # , options={'ftol': 1e-9, 'disp': True})
        a_dic[(i,j)] = SVM_kernel_dic[(i,j)].x
        print(time.time() - start)
print(time.time() - start)
```

    6732.54993891716



```python
a_list = np.zeros((len(C_list),len(gamma_list),n))

for i in range(len(C_list)):
    for j in range(len(gamma_list)):
        a_list[i][j] = a_dic[(i,j)]
```


```python
supp_vec_alpha = np.zeros((len(C_list), len(gamma_list),n))

for k in range(len(gamma_list)):
    for i in range(len(C_list)):
        v = 0
        q = 0
        for j in range(n):
            if a_list[i][k][j] > 0: 
                u = j
                supp_vec_alpha[i][k][j] = a_list[i][k][u]
```


```python
b_list = np.zeros((len(C_list), len(gamma_list)))

for k in range(len(gamma_list)):
    for i in range(len(C_list)):
        v = 0
        q = 0
        for j in range(n):
            if 1e-6 < a_list[i][k][j] < C_list[i] - 1e-8:
                v = v + 1
                q = q + Y[j]- sum(a_list[i][k][r]*Y[r]*Ker[k][r][j] for r in range(n))

        b_list[i][k] = q/v
```

# Prediction and Errors


```python
def sgn(x):
    if x >=0:
        return 1
    else:
        return -1
```


```python
def predict(x, gamma, C):
    
    for j in range(len(C_list)):
        if C == C_list[j]:
            l = j

    for k in range(len(gamma_list)):
        if gamma == gamma_list[k]:
            p = k 
     
    return sgn(sum(supp_vec_alpha[l][p][i]*Y[i]*K(X[i], x, gamma) for i in range(n))+ b_list[l][p])    
```


```python
start = time.time()
label_train_predict = np.ones((len(C_list), len(gamma_list),n))

for j in range(len(C_list)):
    for k in range(len(gamma_list)):
        for i in range(n):
            label_train_predict[j][k][i] = predict(X[i],gamma_list[k], C_list[j])
            
print(time.time() - start)
```

    452.26827216148376



```python
start = time.time()
c = np.zeros((len(C_list),len(gamma_list)))

for j in range(len(C_list)):
    for k in range(len(gamma_list)):
        for i in range(n):
            if label_train_predict[j][k][i] != Y[i]:
                c[j][k] = c[j][k] + 1
print("Train error =", c/len(X))
print("Number of missclassified train examples:", c)
print(time.time() - start)
```

    Train error = [[0.44610092 0.40711009 0.09518349 0.00344037 0.01605505]
     [0.         0.         0.         0.         0.00802752]
     [0.         0.         0.         0.         0.00344037]]
    Number of missclassified train examples: [[389. 355.  83.   3.  14.]
     [  0.   0.   0.   0.   7.]
     [  0.   0.   0.   0.   3.]]
    0.028197050094604492



```python
label_test_predict = np.ones((len(C_list),len(gamma_list),m))

for j in range(len(C_list)):
    for k in range(len(gamma_list)):
        for i in range(m):
            label_test_predict[j][k][i] = predict(test[i][:-1],gamma_list[k], C_list[j])
            
```


```python
e = np.zeros((len(C_list),len(gamma_list)))

for j in range(len(C_list)):
    for k in range(len(gamma_list)):
        for i in range(m):
            if label_test_predict[j][k][i] != test[i][-1]:
                e[j][k] = e[j][k] + 1
print("Train error =", e/len(test))
print("Number of missclassified train examples:", e)
```

    Train error = [[0.442 0.426 0.192 0.004 0.014]
     [0.348 0.018 0.004 0.    0.006]
     [0.232 0.01  0.004 0.    0.004]]
    Number of missclassified train examples: [[221. 213.  96.   2.   7.]
     [174.   9.   2.   0.   3.]
     [116.   5.   2.   0.   2.]]



```python
d1 = {}
d2 = {}
d3 = {}
Dic = [d1,d2,d3]

for i in range(len(C_list)):
    for k in range(len(gamma_list)):
        Dic[i][k+1] = [C_list[i]*(n+1), gamma_list[k], c[i][k]/n, e[i][k]/m, b_list[i][k]]
```


```python
pd.DataFrame.from_dict(Dic[0], orient='index', 
                       columns=['873*C = 100','gamma','Train Error', 'Test Error', 'Biased'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C = 100</th>
      <th>gamma</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Biased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>100.0</td>
      <td>0.1</td>
      <td>0.446101</td>
      <td>0.442</td>
      <td>-0.883218</td>
    </tr>
    <tr>
      <td>2</td>
      <td>100.0</td>
      <td>0.5</td>
      <td>0.407110</td>
      <td>0.426</td>
      <td>-0.676788</td>
    </tr>
    <tr>
      <td>3</td>
      <td>100.0</td>
      <td>1.0</td>
      <td>0.095183</td>
      <td>0.192</td>
      <td>-0.429941</td>
    </tr>
    <tr>
      <td>4</td>
      <td>100.0</td>
      <td>5.0</td>
      <td>0.003440</td>
      <td>0.004</td>
      <td>-0.135006</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.016055</td>
      <td>0.014</td>
      <td>0.187883</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.DataFrame.from_dict(Dic[1], orient='index', 
                       columns=['873*C = 500','gamma','Train Error', 'Test Error', 'Biased'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C = 500</th>
      <th>gamma</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Biased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>500.0</td>
      <td>0.1</td>
      <td>0.000000</td>
      <td>0.348</td>
      <td>-0.420552</td>
    </tr>
    <tr>
      <td>2</td>
      <td>500.0</td>
      <td>0.5</td>
      <td>0.000000</td>
      <td>0.018</td>
      <td>-0.204367</td>
    </tr>
    <tr>
      <td>3</td>
      <td>500.0</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.004</td>
      <td>-0.177199</td>
    </tr>
    <tr>
      <td>4</td>
      <td>500.0</td>
      <td>5.0</td>
      <td>0.000000</td>
      <td>0.000</td>
      <td>-0.125299</td>
    </tr>
    <tr>
      <td>5</td>
      <td>500.0</td>
      <td>100.0</td>
      <td>0.008028</td>
      <td>0.006</td>
      <td>0.375431</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.DataFrame.from_dict(Dic[2], orient='index', 
                       columns=['873*C = 700','gamma','Train Error', 'Test Error', 'Biased'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C = 700</th>
      <th>gamma</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Biased</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>700.0</td>
      <td>0.1</td>
      <td>0.00000</td>
      <td>0.232</td>
      <td>-0.250504</td>
    </tr>
    <tr>
      <td>2</td>
      <td>700.0</td>
      <td>0.5</td>
      <td>0.00000</td>
      <td>0.010</td>
      <td>-0.176974</td>
    </tr>
    <tr>
      <td>3</td>
      <td>700.0</td>
      <td>1.0</td>
      <td>0.00000</td>
      <td>0.004</td>
      <td>-0.165587</td>
    </tr>
    <tr>
      <td>4</td>
      <td>700.0</td>
      <td>5.0</td>
      <td>0.00000</td>
      <td>0.000</td>
      <td>-0.119374</td>
    </tr>
    <tr>
      <td>5</td>
      <td>700.0</td>
      <td>100.0</td>
      <td>0.00344</td>
      <td>0.004</td>
      <td>0.384519</td>
    </tr>
  </tbody>
</table>
</div>



# Part (c)


```python
supp_vec = [[0] * len(gamma_list)] * len(C_list) 

I_list = []
count = np.zeros((len(C_list), len(gamma_list)))

for j in range(len(C_list)):
    for k in range(len(gamma_list)):
        I = [] 
        v = 0
        for i in range(n):
            if a_list[j][k][i] > 1e-6:
                I.append(i)
                v = v + 1
                
        I_list.append(I)
        count[j][k] = v
        supp_vec[j][k] = X[I, :]

```


```python
count
```




    array([[869., 825., 805., 442., 290.],
           [869., 731., 556., 208., 116.],
           [868., 694., 528., 194.,  99.]])




```python
I_list1 = [I_list[:5], I_list[5:10], I_list[10:]]
```


```python
data = {'C = 100/873': count[0], 'C = 500/873': count[1], 'C = 700/873': count[2]}
pd.DataFrame.from_dict(data, orient='index', 
                       columns=['gamma = 0.1','gamma = 0.5','gamma = 1', 'gamma =5', 'gamma =100'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gamma = 0.1</th>
      <th>gamma = 0.5</th>
      <th>gamma = 1</th>
      <th>gamma =5</th>
      <th>gamma =100</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>C = 100/873</td>
      <td>869.0</td>
      <td>825.0</td>
      <td>805.0</td>
      <td>442.0</td>
      <td>290.0</td>
    </tr>
    <tr>
      <td>C = 500/873</td>
      <td>869.0</td>
      <td>731.0</td>
      <td>556.0</td>
      <td>208.0</td>
      <td>116.0</td>
    </tr>
    <tr>
      <td>C = 700/873</td>
      <td>868.0</td>
      <td>694.0</td>
      <td>528.0</td>
      <td>194.0</td>
      <td>99.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Same = np.zeros(len(gamma_list)-1)

for k in range(len(gamma_list)-1):
    for i in range(len(I_list[5:10][k])):
        if I_list[:5][k][i] in I_list[5:10][k+1]:
            Same[k] += 1
```


```python
S = list(Same)
S
```




    [731.0, 493.0, 145.0, 52.0]




```python
dd = {'': ["Number of overlapped support vectors:"] + S}
pd.DataFrame.from_dict(dd, orient='index', 
                       columns=['(gamma_i, gamma_i+1):', '(0.1, 0.5)', 
                                '(0.5, 1)','(1, 5)', '(5, 10)'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>(gamma_i, gamma_i+1):</th>
      <th>(0.1, 0.5)</th>
      <th>(0.5, 1)</th>
      <th>(1, 5)</th>
      <th>(5, 10)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
      <td>Number of overlapped support vectors:</td>
      <td>731.0</td>
      <td>493.0</td>
      <td>145.0</td>
      <td>52.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
