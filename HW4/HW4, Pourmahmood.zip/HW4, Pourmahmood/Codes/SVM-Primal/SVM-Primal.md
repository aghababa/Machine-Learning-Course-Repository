# Processing Data


```python
import numpy as np
from numpy import linalg as LA
import random
import time
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```

# Primal SVM


```python
from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t))
```


```python
@jit(nopython = True)
def Objective_func(W, C, train):
    
    summ = (1/2) * W[:-1].dot(W[:-1])
    
    for i in range(len(train)):
        summ = summ + C * max(0, 1 - train[i][-1] * W.dot(train[i][:-1]))
    return(summ)
```


```python
def SVM(T, C, train, d, gamma_0, W_0): 
    
    WW = []
    Obj_func = [] # we will use Obj_func[1:] for plotting 
    Obj_func.append(0)
    count = 0
    N = len(train)
    V = np.array([1] * (len(W_0)-1)+[0])
    
    W = W_0
    for t in range(1, T+1): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(N): # for x in train: if x[-1]* ...
            if train[i][-1] * W.dot(train[i][:-1]) <= 1:
                W = W - gamma(t,gamma_0,d)*(V*W) + gamma(t,gamma_0,d)*C*N*(train[i][-1]*train[i][:-1])
            else: 
                W[:-1] = (1- gamma(t,gamma_0,d)) * W[:-1]
        
            WW.append(W)
            count = count +1 
            Obj_func.append(Objective_func(W, C, train))
    
    return(Obj_func[1:], W, WW, count)
```

# Part (a)


```python
W_0 = np.zeros(5)
C = 1/873
T = 100
gamma_0 = 2
d = 1

Start_time = time.time()
Obj_func, W,WW, count = SVM(T, C, train, d, gamma_0, W_0)
#time = time.time() - Start_time
print(time.time() - Start_time)

print("Weight vector is:", W) 
print(count)
#print("Loss is:", Obj_func[1:])
```

    12.063894987106323
    Weight vector is: [-0.41387921 -0.26954318 -0.1883254  -0.04172144  0.68078974]
    87200



```python
Obj_func[1:][:3]
```




    [1.2276586971119146, 28.971908680112946, 5.080120394324424]




```python
import matplotlib.pyplot as plt

plt.plot(Obj_func)
plt.show()
```


![png](output_11_0.png)


# Train Error


```python
a = 0
m = len(train)
for i in range(m):
    if train[i][-1] * W.dot(train[i][:-1]) < 0:
        a = a + 1
a, a/m
```




    (34, 0.0389908256880734)



# Test Error


```python
b = 0
n = len(test)
for i in range(n):
    if test[i][-1] * W.dot(test[i][:-1]) < 0:
        b = b + 1
b, b/n
```




    (18, 0.036)



# Different Values of C


```python
C_list = [100/873, 500/873, 700/873]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = 0.0001 
Obj_func = [0] * len(C_list)
W = [0] * len(C_list)
WW = [0] * len(C_list)
count = [0] * len(C_list)

for i in range(len(C_list)):
    
    Obj_func[i], W[i], WW[i], count[i] = SVM(T, C_list[i], train, d, gamma_0, W_0)

```


```python
for i in range(len(C_list)):
    plt.plot(Obj_func[i])
    plt.show()
```


![png](output_18_0.png)



![png](output_18_1.png)



![png](output_18_2.png)



```python
W
```




    [array([-0.87184498, -0.60889615, -0.67538486, -0.0416877 ,  1.27410346]),
     array([-1.90745924, -1.18856178, -1.41239681, -0.21485184,  1.9958197 ]),
     array([-2.31125344, -1.40029882, -1.67290295, -0.25867937,  2.22483364])]



# Train Error


```python
a = np.zeros(len(C_list))
m = len(train)

for j in range(len(C_list)):
    for i in range(m):
        if train[i][-1] * W[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)
```

    Number of training errors for each choice of C: [10.  7. 10.] 
    
    Train Error = [0.01146789 0.00802752 0.01146789]


# Test Error


```python
b = np.zeros(len(C_list))
n = len(test)

for j in range(len(C_list)):
    for i in range(n):
        if test[i][-1] * W[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)
```

    Number of test errors for each choice of C: [6. 5. 6.] 
    
    Test Error = [0.012 0.01  0.012]


# Representation in the form of Dataframe


```python
import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW[-1][872*t-1], 5), Obj_func[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head(10) 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>T</th>
      <th>Weights (rounded to 5 decimals)</th>
      <th>Loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>1</td>
      <td>[-2.02557, -1.22867, -1.77848, -0.25581, 2.09759]</td>
      <td>91.405064</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2</td>
      <td>[-2.34717, -1.40022, -1.61414, -0.29573, 2.23078]</td>
      <td>21.116103</td>
    </tr>
    <tr>
      <td>3</td>
      <td>3</td>
      <td>[-2.26766, -1.42011, -1.7889, -0.23921, 2.29844]</td>
      <td>26.785545</td>
    </tr>
    <tr>
      <td>4</td>
      <td>4</td>
      <td>[-2.21046, -1.39671, -1.87883, -0.21476, 2.3496]</td>
      <td>54.491251</td>
    </tr>
    <tr>
      <td>5</td>
      <td>5</td>
      <td>[-2.24888, -1.40932, -1.69754, -0.43423, 2.43186]</td>
      <td>21.482518</td>
    </tr>
    <tr>
      <td>6</td>
      <td>6</td>
      <td>[-2.26311, -1.51941, -1.69277, -0.29085, 2.39747]</td>
      <td>21.538867</td>
    </tr>
    <tr>
      <td>7</td>
      <td>7</td>
      <td>[-2.28772, -1.51838, -1.67042, -0.32083, 2.38762]</td>
      <td>22.793225</td>
    </tr>
    <tr>
      <td>8</td>
      <td>8</td>
      <td>[-2.27544, -1.42879, -1.80769, -0.27213, 2.34446]</td>
      <td>27.899519</td>
    </tr>
    <tr>
      <td>9</td>
      <td>9</td>
      <td>[-2.27629, -1.44636, -1.80314, -0.24741, 2.31373]</td>
      <td>25.861827</td>
    </tr>
    <tr>
      <td>10</td>
      <td>10</td>
      <td>[-2.32499, -1.50382, -1.67376, -0.28917, 2.31373]</td>
      <td>22.231924</td>
    </tr>
  </tbody>
</table>
</div>




```python
W_round = np.around(W, decimals = 5)

Dic = {}
    
for i in range(len(C_list)): 
    Dic[i+1] = [C_list[i] * 873, a[i]/m, b[i]/n, W_round[i]]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['873*C','Train Error', 'Test Error', 'Weights (rounded to 5 decimals)'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Weights (rounded to 5 decimals)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>100.0</td>
      <td>0.011468</td>
      <td>0.012</td>
      <td>[-0.87184, -0.6089, -0.67538, -0.04169, 1.2741]</td>
    </tr>
    <tr>
      <td>2</td>
      <td>500.0</td>
      <td>0.008028</td>
      <td>0.010</td>
      <td>[-1.90746, -1.18856, -1.4124, -0.21485, 1.99582]</td>
    </tr>
    <tr>
      <td>3</td>
      <td>700.0</td>
      <td>0.011468</td>
      <td>0.012</td>
      <td>[-2.31125, -1.4003, -1.6729, -0.25868, 2.22483]</td>
    </tr>
  </tbody>
</table>
</div>



# Part (b)


```python
C_list = [100/873, 500/873, 700/873]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = gamma_0
Obj_func_b = [0] * len(C_list)
W_b = [0] * len(C_list)
WW_b = [0] * len(C_list)
count_b = [0] * len(C_list)

for i in range(len(C_list)):
    
    Obj_func_b[i], W_b[i], WW_b[i], count_b[i] = SVM(T, C_list[i], train, d, gamma_0, W_0)

```


```python
for i in range(len(C_list)):
    plt.plot(Obj_func_b[i])
    plt.show()
```


![png](output_29_0.png)



![png](output_29_1.png)



![png](output_29_2.png)



```python
W_b
```




    [array([-0.99179023, -0.69137502, -0.78750943, -0.05951468,  1.43281211]),
     array([-2.2851855 , -1.42426737, -1.64891987, -0.24906291,  2.25193929]),
     array([-2.68562058, -1.58096185, -1.92669318, -0.33096357,  2.67223178])]



# Train Error


```python
a = np.zeros(len(C_list))
m = len(train)

for j in range(len(C_list)):
    for i in range(m):
        if train[i][-1] * W_b[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)
```

    Number of training errors for each choice of C: [ 6. 10.  7.] 
    
    Train Error = [0.00688073 0.01146789 0.00802752]


# Test Error


```python
b = np.zeros(len(C_list))
n = len(test)

for j in range(len(C_list)):
    for i in range(n):
        if test[i][-1] * W_b[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)
```

    Number of test errors for each choice of C: [4. 5. 5.] 
    
    Test Error = [0.008 0.01  0.01 ]


# Representation in the form of Dataframe


```python
import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW_b[-1][872*t-1], 5), Obj_func_b[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head(10) 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>T</th>
      <th>Weights (rounded to 5 decimals)</th>
      <th>Loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>1</td>
      <td>[-10.93215, -6.83847, -4.69382, -2.07842, 6.64...</td>
      <td>375.361771</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2</td>
      <td>[-8.27882, -5.88473, -7.59346, -1.69394, 8.50691]</td>
      <td>202.842972</td>
    </tr>
    <tr>
      <td>3</td>
      <td>3</td>
      <td>[-7.7023, -5.75047, -5.71687, -0.97022, 8.85651]</td>
      <td>114.617183</td>
    </tr>
    <tr>
      <td>4</td>
      <td>4</td>
      <td>[-7.42253, -4.24973, -4.92419, -1.1072, 8.99635]</td>
      <td>85.861429</td>
    </tr>
    <tr>
      <td>5</td>
      <td>5</td>
      <td>[-7.18585, -4.15821, -4.98283, -0.2853, 8.41368]</td>
      <td>69.774044</td>
    </tr>
    <tr>
      <td>6</td>
      <td>6</td>
      <td>[-7.01815, -4.6684, -3.83073, -0.62617, 8.21391]</td>
      <td>154.847184</td>
    </tr>
    <tr>
      <td>7</td>
      <td>7</td>
      <td>[-6.73797, -4.33983, -3.78359, -0.51548, 7.77691]</td>
      <td>127.984670</td>
    </tr>
    <tr>
      <td>8</td>
      <td>8</td>
      <td>[-6.4521, -3.21551, -4.6478, -0.2395, 7.46616]</td>
      <td>90.575083</td>
    </tr>
    <tr>
      <td>9</td>
      <td>9</td>
      <td>[-6.01119, -3.27233, -4.55026, 0.16166, 7.11656]</td>
      <td>86.017186</td>
    </tr>
    <tr>
      <td>10</td>
      <td>10</td>
      <td>[-6.0015, -3.12307, -4.35502, -0.1996, 6.92587]</td>
      <td>69.934075</td>
    </tr>
  </tbody>
</table>
</div>




```python
W_round_b = np.around(W_b, decimals = 5)

Dic = {}
    
for i in range(len(C_list)): 
    Dic[i+1] = [C_list[i] * 873, a[i]/m, b[i]/n, W_round_b[i]]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['873*C','Train Error', 'Test Error', 'Weights (rounded to 5 decimals)'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Weights (rounded to 5 decimals)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>100.0</td>
      <td>0.006881</td>
      <td>0.008</td>
      <td>[-0.99179, -0.69138, -0.78751, -0.05951, 1.43281]</td>
    </tr>
    <tr>
      <td>2</td>
      <td>500.0</td>
      <td>0.011468</td>
      <td>0.010</td>
      <td>[-2.28519, -1.42427, -1.64892, -0.24906, 2.25194]</td>
    </tr>
    <tr>
      <td>3</td>
      <td>700.0</td>
      <td>0.008028</td>
      <td>0.010</td>
      <td>[-2.68562, -1.58096, -1.92669, -0.33096, 2.67223]</td>
    </tr>
  </tbody>
</table>
</div>



# Part (c)


```python
LA.norm(W[0]-W_b[0]), LA.norm(W[1]-W_b[1]), LA.norm(W[2]-W_b[2])
```




    (0.24344975580402772, 0.566520126618903, 0.6652739853617669)




```python

```
