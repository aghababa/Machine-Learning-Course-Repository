# Processing Data


```python
import numpy as np
import pandas as pd 
import random 
import math
import time
from scipy import linalg as LA
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```


```python
n = len(train)
m = len(test)
d = len(train[0]) - 1
```


```python
train.shape, test.shape, d, n
```




    ((872, 6), (500, 6), 5, 872)




```python
X = train[:,:-1]
Y = train[:,-1]
y = train[:,-1:]
```

# Nonlinear Perceptron with Gaussian Kernel


```python
gamma_list = [0.1,0.5,1,5,100]
```


```python
def K(x,z,gamma):
    return(math.exp((- LA.norm(x-z)**2)/gamma))
```


```python
def Gram(A, B, gamma):  
    temp = np.sum(A**2,1).reshape(A.shape[0],1) + np.sum(B**2,1).reshape(1,B.shape[0])-2* A @ B.T
    return np.exp(-temp/gamma)
```


```python
start = time.time()
c = np.zeros((len(gamma_list),n))
T = 100

for k in range(len(gamma_list)):
    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        G = Gram(train[:,:-1],train[:,:-1],gamma_list[k])
        for i in range(n):
            if train[:,-1][i] * ((c[k] * train[:,-1]) @ G[i]) <= 0:
                c[k][i] = c[k][i] + 1 

print(time.time() - start)
print(c)
```

    38.8327898979187
    [[ 1.  1.  1. ...  1.  0.  0.]
     [ 1.  1.  1. ...  0.  0.  0.]
     [ 1.  1.  0. ...  0.  0.  0.]
     [ 2.  1.  1. ...  1.  0.  0.]
     [17. 29. 21. ... 12. 14.  5.]]



```python
def sgn(x):
    if x >=0:
        return 1
    else:
        return -1
```


```python
def predict(Z,k):
    Q = sum(c[k].reshape(-1,1) * train[:,-1].reshape(-1,1) * Gram(train[:,:-1],Z,gamma_list[k]),0) # 0: add rows
    return np.where(Q >= 0, 1,-1)
```


```python
start = time.time()
a = np.zeros(len(gamma_list))

for k in range(len(gamma_list)):
    P = predict(X,k)
    for i in range(n):
        if P[i] * Y[i] < 0:
            a[k] = a[k] + 1
print("Train error =", a/n)
print("Number of missclassified train examples:", a)
print(time.time() - start)
```

    Train error = [0.         0.         0.         0.00917431 0.18004587]
    Number of missclassified train examples: [  0.   0.   0.   8. 157.]
    0.3432331085205078



```python
start = time.time()
b = np.zeros(len(gamma_list))

for k in range(len(gamma_list)):
    P = predict(test[:,:-1],k)
    for i in range(m):
        if P[i] * test[i][-1] < 0:
            b[k] = b[k] + 1
            
print("Test error =", b/m)
print("Number of missclassified test examples:", b)
print(time.time() - start)
```

    Test error = [0.004 0.    0.002 0.008 0.176]
    Number of missclassified test examples: [ 2.  0.  1.  4. 88.]
    0.22958993911743164



```python
Dic = {}

for k in range(len(gamma_list)):
    Dic[k+1] = [gamma_list[k], a[k]/n, b[k]/m]
```


```python
pd.DataFrame.from_dict(Dic, orient='index', columns=['gamma','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gamma</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>0.1</td>
      <td>0.000000</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>2</td>
      <td>0.5</td>
      <td>0.000000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <td>3</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.002</td>
    </tr>
    <tr>
      <td>4</td>
      <td>5.0</td>
      <td>0.009174</td>
      <td>0.008</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100.0</td>
      <td>0.180046</td>
      <td>0.176</td>
    </tr>
  </tbody>
</table>
</div>



# Without shuffeling with T=1


```python

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gamma</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>0.1</td>
      <td>0.002294</td>
      <td>0.002</td>
    </tr>
    <tr>
      <td>2</td>
      <td>0.5</td>
      <td>0.000000</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>3</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>4</td>
      <td>5.0</td>
      <td>0.000000</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100.0</td>
      <td>0.033257</td>
      <td>0.046</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
