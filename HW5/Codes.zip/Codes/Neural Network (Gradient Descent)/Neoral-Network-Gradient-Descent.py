#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[67]:


import numpy as np
import random
import time
import math
import pandas as pd 
from scipy import linalg as LA


# In[68]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[69]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)


# In[70]:


n = len(train)
m = len(test)


# In[71]:


c1 = 0
for i in range(n):
    if train[i][-1] > 0:
        c1 = c1 + 1
c1


# # Back Propagation

# In[6]:


from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t)) 


# In[7]:


def sigmoid1(z):
    return 1/(1+ math.exp(-z))

sigmoid = np.vectorize(sigmoid1)


# In[8]:


# Generating a Gaussian random variable matrix  
# np.random.normal(mean, standard deviation, shape)
#np.random.normal(0, 1, (2,3))


# In[9]:


class NeuralNetwork():
    
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        
        self.num_nodes_hid_layers_1 = num_nodes_hid_layers_1
        self.num_nodes_hid_layers_2 = num_nodes_hid_layers_2
        self.num_input_nodes = num_input_nodes
        self.num_output_nodes = num_output_nodes      
                
        self.weights_layer_1 = np.random.normal(0, 1, (self.num_nodes_hid_layers_1 -1, self.num_input_nodes))
        self.weights_layer_2 = np.random.normal(0, 1, (self.num_nodes_hid_layers_2 -1, self.num_nodes_hid_layers_1))
        self.weights_layer_3 = np.random.normal(0, 1, (self.num_output_nodes, self.num_nodes_hid_layers_2))


    def ForwardPass(self, x):

        x = x.reshape(-1,1)

        self.temp_1 = sigmoid(self.weights_layer_1 @ x)
        # temp_1 is values of z in layer 1, i.e. z_0^1, z_1^1, z_2^1

        self.temp_2 = sigmoid(self.weights_layer_2 @ np.concatenate((self.temp_1, np.array([[1]])), axis = 0))
        # temp_2 is values of z in layer 2, i.e. z_0^2, z_1^2, z_2^2
        
        self.temp_3 = self.weights_layer_3 @ np.concatenate((self.temp_2, np.array([[1]])), axis = 0)
        # temp_3 is values of what going to resige in sign function to give y 

        return(np.sign(self.temp_3))
        # returnes the y value
        
    
    def Backpropagation(self, x, y, gamma_0, d): # y=label(x)

        x = x.reshape(-1,1)
        
        temp_11 = sigmoid(self.weights_layer_1 @ x)
        
        temp_22 = sigmoid(self.weights_layer_2 @ np.concatenate((temp_11, np.array([[1]])), axis = 0))

        temp_33 = self.weights_layer_3 @ np.concatenate((temp_22, np.array([[1]])), axis = 0)
        
        temp = temp_33 - y
        self.grad_output = temp * (np.concatenate((temp_22, [[1]]), axis = 0)).T
    
        
        t = temp * self.weights_layer_3[:1, :-1] * temp_22.T*(1 - temp_22.T)
        self.grad_level_1 = (t * np.concatenate((temp_11, np.array([[1]])), axis = 0)).T
        
        Q = np.zeros((self.num_nodes_hid_layers_1 -1))
        for i in range(self.num_nodes_hid_layers_1 -1):
            Q[i] = (t @ self.weights_layer_2[:,i].T) * (temp_11.T * (1 - temp_11).T)[0,i]
        
        self.grad_level_0 = Q.reshape(-1,1) @ x.T
        
        return(self.grad_level_0, self.grad_level_1, self.grad_output)
    
    def fun(self, x, y, gamma_0, d, number_of_iterations):
        self.Backpropagation(x, y, gamma_0, d)
        
        self.weights_layer_3 = self.weights_layer_3 - gamma(number_of_iterations, gamma_0, d) * self.grad_output
        self.weights_layer_2 = self.weights_layer_2 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_1
        self.weights_layer_1 = self.weights_layer_1 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_0 
        number_of_iterations = number_of_iterations + 1
        
        return(number_of_iterations)


# # Stochastic Gradient Descent

# In[32]:


start = time.time()
width_list = [5, 10, 25, 50, 100]
T = 20
gamma_0 = 0.02
d = 2
w_list = []
N = [0] * len(width_list)

for k in range(len(width_list)):
    start1 = time.time()
    N[k] = NeuralNetwork(num_nodes_hid_layers_1 = width_list[k], num_nodes_hid_layers_2 = 
                         width_list[k], num_input_nodes = 5, num_output_nodes = 1)

    w = np.array([N[k].weights_layer_1, N[k].weights_layer_2, N[k].weights_layer_3])

    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(n):
            N[k].fun(train[i][:-1], train[i][-1], gamma_0, d, 1)
            w = w - np.array([[gamma(t, gamma_0, d)]]) * N[k].Backpropagation(
                train[i][:-1], train[i][-1], gamma_0, d)
            
    
    print(time.time() - start1)
    w_list.append(w)

print(time.time() - start)


# # Train Error

# In[33]:


a = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(n):
        if train[i][-1] * N[k].ForwardPass(train[i][:-1]) < 0:
            a[k] = a[k] + 1
a, a/n


# # Test Error

# In[34]:


b = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(m):
        if test[i][-1] * N[k].ForwardPass(test[i][:-1]) < 0:
            b[k] = b[k] + 1
b, b/m


# In[35]:


weight = [0] * len(width_list)

for k in range(len(width_list)):
    weight[k] = w_list[k][-1][-1][-1]


# # Presentation of errors on dataframe

# In[31]:


T = 1
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[26]:


T = 5
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[21]:


T = 10
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[36]:


T = 20
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# # Initializing with 0 weights

# In[111]:


class NeuralNetwork_0(NeuralNetwork):
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        super().__init__(num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes)
        
        self.weights_layer_1 = np.zeros((self.num_nodes_hid_layers_1 -1, self.num_input_nodes))
        self.weights_layer_2 = np.zeros((self.num_nodes_hid_layers_2 -1, self.num_nodes_hid_layers_1))
        self.weights_layer_3 = np.zeros((self.num_output_nodes, self.num_nodes_hid_layers_2))


# In[118]:


start = time.time()
width_list = [5, 10, 25, 50, 100]
T = 1
gamma_0 = 0.02
d = 2
w_0_list = []
N_0 = [0] * len(width_list)

for k in range(len(width_list)):
    start1 = time.time()
    N_0[k] = NeuralNetwork_0(num_nodes_hid_layers_1 = width_list[k], num_nodes_hid_layers_2 = 
                         width_list[k], num_input_nodes = 5, num_output_nodes = 1)

    w = np.array([N_0[k].weights_layer_1, N_0[k].weights_layer_2, N_0[k].weights_layer_3])

    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(n):
            N_0[k].fun_0(train[i][:-1], train[i][-1], gamma_0, d, 1)
            w = w - np.array([[gamma(t, gamma_0, d)]]) * N_0[k].Backpropagation_0(train[i][:-1], train[i][-1], gamma_0, d)
    
    print(time.time() - start1)
    w_0_list.append(w)

print(time.time() - start)


# In[119]:


a0 = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(n):
        if train[i][-1] * N_0[k].ForwardPass_0(train[i][:-1]) < 0:
            a0[k] = a0[k] + 1
a0, a0/n


# In[120]:


b0 = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(m):
        if test[i][-1] * N_0[k].ForwardPass_0(test[i][:-1]) < 0:
            b0[k] = b0[k] + 1
b0, b0/m


# In[121]:


T = 1
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[106]:


T = 5
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[110]:


T = 10
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[117]:


T = 20
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])


# In[ ]:




