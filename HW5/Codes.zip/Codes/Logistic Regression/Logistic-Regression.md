# Processing Data


```python
import numpy as np
import random
import time
import math
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```

# Logistic Regression


```python
from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t))
```


```python
@jit(nopython = True)
def Objective_func1(W, v, train):
    
    summ = (1/(2*v)) * W.dot(W) 
    
    for i in range(len(train)):
        summ = summ + np.log(1 + math.exp(-train[i][-1] * W.dot(train[i][:-1])))
    return(summ)
```


```python
@jit(nopython = True)
def Objective_func(W, v, x, y, N):
    
    if - y * W.dot(x) > 200: # 709
        L = (1/(2*v)) * W.dot(W) + N * np.log(1 + math.exp(200))

    else: 
        L = (1/(2*v)) * W.dot(W) + N * np.log(1 + math.exp(- y * W.dot(x)))
    
    return(L)
```


```python
def sigmoid(z):
    if z < -200:
        return 0
    else:
        return 1/(1+ math.exp(-z))

#sigmoid = np.vectorize(sigmoid)
```


```python
def Lojistic_Regression(T, v, train, d, gamma_0, W_0): 
    
    WW = []
    Obj_func = []  
    count = 0
    N = len(train)
    
    W = W_0
    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(N): 
            grad_SGD = (1/v) * W - N * train[i][-1] * (1 - sigmoid(train[i][-1] * W.dot(train[i][:-1]))) * train[i][:-1]
            W = W - gamma(t,gamma_0,d) * grad_SGD

            WW.append(W)
            count = count +1 
            #Obj_func.append(Objective_func1(W, v, train))
            Obj_func.append(Objective_func(W, v, train[i][:-1], train[i][-1],N))
    
    return(Obj_func, W, WW, count)
```

# Different Values of v


```python
Start_time = time.time()
v_list = [0.01, 0.1, 0.5, 1, 3, 5, 10, 100]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = 0.002
Obj_func = [0] * len(v_list)
W = [0] * len(v_list)
WW = [0] * len(v_list)
count = [0] * len(v_list)

for i in range(len(v_list)):
    
    Start_time1 = time.time()
    Obj_func[i], W[i], WW[i], count[i] = Lojistic_Regression(T, v_list[i], train, d, gamma_0, W_0)
    print(time.time() - Start_time1)
    
print('time =', time.time() - Start_time)
```

    5.950363874435425
    7.524610996246338
    4.489231824874878
    3.9458696842193604
    3.9501230716705322
    4.115026950836182
    4.382761001586914
    3.9615039825439453
    38.41502380371094



```python
for i in range(len(v_list)):
    plt.plot(Obj_func[i])
    plt.show()
```


![png](output_12_0.png)



![png](output_12_1.png)



![png](output_12_2.png)



![png](output_12_3.png)



![png](output_12_4.png)



![png](output_12_5.png)



![png](output_12_6.png)



![png](output_12_7.png)



```python
W
```




    [array([ 0.43544641, -0.8502986 , -0.38215992, -0.48665322, -0.12979333]),
     array([ 1.49970562, -1.51039149, -0.925252  , -0.98277788, -0.178601  ]),
     array([ 2.46620164, -2.2567308 , -1.38124754, -1.60925461, -0.19171276]),
     array([ 2.89067736, -2.76907416, -1.66199992, -1.92877508, -0.19552522]),
     array([ 4.45941577, -4.58597208, -2.668911  , -3.20450743, -0.41330734]),
     array([ 7.99684804, -8.70820837, -4.75027015, -5.90610008, -0.789144  ]),
     array([ 13.36552228, -14.67439497,  -7.94597787,  -9.95384628,
             -1.44034741]),
     array([ 24.49146322, -26.6086868 , -14.1743346 , -18.08862533,
             -2.51081332])]



# Train Error


```python
a = np.zeros(len(v_list))
m = len(train)

for j in range(len(v_list)):
    for i in range(m):
        if train[i][-1] * W[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)
```

    Number of training errors for each choice of C: [18. 11.  8. 10. 10. 10.  8.  8.] 
    
    Train Error = [0.0206422  0.01261468 0.00917431 0.01146789 0.01146789 0.01146789
     0.00917431 0.00917431]


# Test Error


```python
b = np.zeros(len(v_list))
n = len(test)

for j in range(len(v_list)):
    for i in range(n):
        if test[i][-1] * W[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)
```

    Number of test errors for each choice of C: [9. 6. 5. 5. 5. 6. 3. 4.] 
    
    Test Error = [0.018 0.012 0.01  0.01  0.01  0.012 0.006 0.008]


# Representation in the form of Dataframe


```python
import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW[-1][872*t-1], 5), Obj_func[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>T</th>
      <th>Weights (rounded to 5 decimals)</th>
      <th>Loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>1</td>
      <td>[16.52768, -26.11598, -17.42282, -18.55227, -4...</td>
      <td>8.100918</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2</td>
      <td>[19.70622, -29.67207, -21.58672, -16.20333, -6...</td>
      <td>10.174522</td>
    </tr>
    <tr>
      <td>3</td>
      <td>3</td>
      <td>[21.47988, -28.80329, -17.52602, -21.75285, -4...</td>
      <td>10.444986</td>
    </tr>
    <tr>
      <td>4</td>
      <td>4</td>
      <td>[22.80866, -28.25425, -18.59652, -20.56494, -5...</td>
      <td>10.566305</td>
    </tr>
    <tr>
      <td>5</td>
      <td>5</td>
      <td>[23.32376, -28.31295, -17.28666, -21.22618, -4...</td>
      <td>10.571814</td>
    </tr>
  </tbody>
</table>
</div>




```python
W_round = np.around(W, decimals = 5)

Dic = {}

v_list1 = ["0.01", "0.1", "0.5", "1", "3", "5", "10", "100"]

for i in range(len(v_list)): 
    Dic[i+1] = [v_list1[i], a[i]/m, b[i]/n]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Variance','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Variance</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>0.01</td>
      <td>0.020642</td>
      <td>0.018</td>
    </tr>
    <tr>
      <td>2</td>
      <td>0.1</td>
      <td>0.012615</td>
      <td>0.012</td>
    </tr>
    <tr>
      <td>3</td>
      <td>0.5</td>
      <td>0.009174</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>4</td>
      <td>1</td>
      <td>0.011468</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>5</td>
      <td>3</td>
      <td>0.011468</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>6</td>
      <td>5</td>
      <td>0.011468</td>
      <td>0.012</td>
    </tr>
    <tr>
      <td>7</td>
      <td>10</td>
      <td>0.009174</td>
      <td>0.006</td>
    </tr>
    <tr>
      <td>8</td>
      <td>100</td>
      <td>0.009174</td>
      <td>0.008</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
