#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[53]:


import numpy as np
import random
import time
import math


# In[54]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[55]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)


# # Logistic Regression

# In[56]:


from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t))


# In[57]:


@jit(nopython = True)
def Objective_func1(W, v, train):
    
    summ = (1/(2*v)) * W.dot(W) 
    
    for i in range(len(train)):
        summ = summ + np.log(1 + math.exp(-train[i][-1] * W.dot(train[i][:-1])))
    return(summ)


# In[58]:


@jit(nopython = True)
def Objective_func(W, v, x, y, N):
    
    if - y * W.dot(x) > 200: # 709
        L = (1/(2*v)) * W.dot(W) + N * np.log(1 + math.exp(200))

    else: 
        L = (1/(2*v)) * W.dot(W) + N * np.log(1 + math.exp(- y * W.dot(x)))
    
    return(L)


# In[59]:


def sigmoid(z):
    if z < -200:
        return 0
    else:
        return 1/(1+ math.exp(-z))

#sigmoid = np.vectorize(sigmoid)


# In[60]:


def Lojistic_Regression(T, v, train, d, gamma_0, W_0): 
    
    WW = []
    Obj_func = []  
    count = 0
    N = len(train)
    
    W = W_0
    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(N): 
            grad_SGD = (1/v) * W - N * train[i][-1] * (1 - sigmoid(train[i][-1] * W.dot(train[i][:-1]))) * train[i][:-1]
            W = W - gamma(t,gamma_0,d) * grad_SGD

            WW.append(W)
            count = count +1 
            #Obj_func.append(Objective_func1(W, v, train))
            Obj_func.append(Objective_func(W, v, train[i][:-1], train[i][-1],N))
    
    return(Obj_func, W, WW, count)


# # Different Values of v

# In[65]:


Start_time = time.time()
v_list = [0.01, 0.1, 0.5, 1, 3, 5, 10, 100]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = 0.002
Obj_func = [0] * len(v_list)
W = [0] * len(v_list)
WW = [0] * len(v_list)
count = [0] * len(v_list)

for i in range(len(v_list)):
    
    Start_time1 = time.time()
    Obj_func[i], W[i], WW[i], count[i] = Lojistic_Regression(T, v_list[i], train, d, gamma_0, W_0)
    print(time.time() - Start_time1)
    
print('time =', time.time() - Start_time)


# In[66]:


for i in range(len(v_list)):
    plt.plot(Obj_func[i])
    plt.show()


# In[67]:


W


# # Train Error

# In[68]:


a = np.zeros(len(v_list))
m = len(train)

for j in range(len(v_list)):
    for i in range(m):
        if train[i][-1] * W[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)


# # Test Error

# In[69]:


b = np.zeros(len(v_list))
n = len(test)

for j in range(len(v_list)):
    for i in range(n):
        if test[i][-1] * W[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)


# # Representation in the form of Dataframe

# In[70]:


import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW[-1][872*t-1], 5), Obj_func[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head() 


# In[71]:


W_round = np.around(W, decimals = 5)

Dic = {}

v_list1 = ["0.01", "0.1", "0.5", "1", "3", "5", "10", "100"]

for i in range(len(v_list)): 
    Dic[i+1] = [v_list1[i], a[i]/m, b[i]/n]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Variance','Train Error', 'Test Error'])


# In[ ]:




