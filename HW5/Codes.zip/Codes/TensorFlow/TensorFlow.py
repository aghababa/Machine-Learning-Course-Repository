#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[2]:


import numpy as np
import tensorflow as tf
from tensorflow import keras
import time
import pandas as pd 


# In[3]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[4]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)        

for i in range(len(train1)):
    train1[i].insert(4,1)

train2 = to_float(train1)
train3 = np.array(train2)

train4 = [0] * len(train1)
for i in range(len(train1)):
    train4[i] = [train3[:,:-1][i]]
    
train = np.array(train4)


# In[5]:


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)

for i in range(len(test1)):
    test1[i].insert(4,1)

test2 = to_float(test1)
test3 = np.array(test2)

test4 = [0] * len(test1)
for i in range(len(test1)):
    test4[i] = [test3[:,:-1][i]]
    
test = np.array(test4)


# ## Model with tanh activation function and "Xavier" initialization (depth = 3)

# In[6]:


width_list = [5, 10, 25, 50, 100]
model_tanh_3 = [0] * len(width_list)

for k in range(len(width_list)):
    model_tanh_3[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[7]:


# Using Adam optimizer for training

Start_time = time.time()
train_loss_tanh_3 = [0] * len(width_list)
train_acc_tanh_3 = [0] * len(width_list)
test_loss_tanh_3 = [0] * len(width_list)
test_acc_tanh_3 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_tanh_3[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_tanh_3[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_tanh_3[k], train_acc_tanh_3[k] = model_tanh_3[k].evaluate(train, train3[:,-1])
    test_loss_tanh_3[k], test_acc_tanh_3[k] = model_tanh_3[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# ## Model with tanh activation function and "Xavier" initialization (depth = 5)

# In[8]:


width_list = [5, 10, 25, 50, 100]
model_tanh_5 = [0] * len(width_list)

for k in range(len(width_list)):
    model_tanh_5[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[9]:


# Using Adam optimizer for training
Start_time = time.time()
train_loss_tanh_5 = [0] * len(width_list)
train_acc_tanh_5 = [0] * len(width_list)
test_loss_tanh_5 = [0] * len(width_list)
test_acc_tanh_5 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_tanh_5[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_tanh_5[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_tanh_5[k], train_acc_tanh_5[k] = model_tanh_5[k].evaluate(train, train3[:,-1])
    test_loss_tanh_5[k], test_acc_tanh_5[k] = model_tanh_5[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# ## Model with tanh activation function and "Xavier" initialization (depth = 9)

# In[10]:


width_list = [5, 10, 25, 50, 100]
model_tanh_9 = [0] * len(width_list)

for k in range(len(width_list)):
    model_tanh_9[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
                        kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(width_list[k], activation=tf.nn.tanh, 
            kernel_initializer='glorot_normal', bias_initializer='zeros'),
     keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[11]:


# Using Adam optimizer for training
Start_time = time.time()
train_loss_tanh_9 = [0] * len(width_list)
train_acc_tanh_9 = [0] * len(width_list)
test_loss_tanh_9 = [0] * len(width_list)
test_acc_tanh_9 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_tanh_9[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_tanh_9[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_tanh_9[k], train_acc_tanh_9[k] = model_tanh_9[k].evaluate(train, train3[:,-1])
    test_loss_tanh_9[k], test_acc_tanh_9[k] = model_tanh_9[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# ## Model with ReLu activation function and "he" initialization (depth = 3)

# In[13]:


model_ReLu_3 = [0] * len(width_list)

for k in range(len(width_list)):
    model_ReLu_3[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[14]:


# Using Adam optimizer for training

Start_time = time.time()
train_loss_ReLu_3 = [0] * len(width_list)
train_acc_ReLu_3 = [0] * len(width_list)
test_loss_ReLu_3 = [0] * len(width_list)
test_acc_ReLu_3 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_ReLu_3[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_ReLu_3[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_ReLu_3[k], train_acc_ReLu_3[k] = model_ReLu_3[k].evaluate(train, train3[:,-1])
    test_loss_ReLu_3[k], test_acc_ReLu_3[k] = model_ReLu_3[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# ## Model with ReLu activation function and "he" initialization (depth = 5)

# In[15]:


model_ReLu_5 = [0] * len(width_list)

for k in range(len(width_list)):
    model_ReLu_5[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[16]:


# Using Adam optimizer for training

Start_time = time.time()
train_loss_ReLu_5 = [0] * len(width_list)
train_acc_ReLu_5 = [0] * len(width_list)
test_loss_ReLu_5 = [0] * len(width_list)
test_acc_ReLu_5 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_ReLu_5[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_ReLu_5[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_ReLu_5[k], train_acc_ReLu_5[k] = model_ReLu_5[k].evaluate(train, train3[:,-1])
    test_loss_ReLu_5[k], test_acc_ReLu_5[k] = model_ReLu_5[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# ## Model with ReLu activation function and "he" initialization (depth = 9)

# In[17]:


model_ReLu_9 = [0] * len(width_list)

for k in range(len(width_list)):
    model_ReLu_9[k] = keras.Sequential([keras.layers.Flatten(input_shape=(1,5)),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(width_list[k], activation=tf.nn.relu, 
            kernel_initializer= 'he_normal', bias_initializer='zeros'),
    keras.layers.Dense(2, activation=tf.nn.softmax)])


# In[18]:


# Using Adam optimizer for training

Start_time = time.time()
train_loss_ReLu_9 = [0] * len(width_list)
train_acc_ReLu_9 = [0] * len(width_list)
test_loss_ReLu_9 = [0] * len(width_list)
test_acc_ReLu_9 = [0] * len(width_list)

for k in range(len(width_list)):
    
    model_ReLu_9[k].compile(optimizer='adam',loss='sparse_categorical_crossentropy', 
                            metrics=['accuracy'])
    
    model_ReLu_9[k].fit(train, train3[:,-1], epochs= 10)
    
    train_loss_ReLu_9[k], train_acc_ReLu_9[k] = model_ReLu_9[k].evaluate(train, train3[:,-1])
    test_loss_ReLu_9[k], test_acc_ReLu_9[k] = model_ReLu_9[k].evaluate(test, test3[:,-1])

print('time =', time.time() - Start_time)


# # Presenting Errors and Accuracies in DataFrame

# In[19]:


Train_Accuracy_tanh = [train_acc_tanh_3, train_acc_tanh_5, train_acc_tanh_9]
Test_Accuracy_tanh = [test_acc_tanh_3, test_acc_tanh_5, test_acc_tanh_9]
Train_Accuracy_ReLu = [train_acc_ReLu_3, train_acc_ReLu_5, train_acc_ReLu_9]
Test_Accuracy_ReLu = [test_acc_ReLu_3, test_acc_ReLu_5, test_acc_ReLu_9]

depth_list = [3,5,9]
dic1 = {}
    
for i in range(len(depth_list)):
    for t in range(len(width_list)): 
        dic1[i,t] = [depth_list[i], width_list[t], 
                     1 - Train_Accuracy_tanh[i][t], 1 - Test_Accuracy_tanh[i][t], 
                     1 - Train_Accuracy_ReLu[i][t], 1 - Test_Accuracy_ReLu[i][t]]
    
df = pd.DataFrame.from_dict(dic1, orient='index', columns=['Depth', 'Width',
                        'Train Error (tanh)', 'Test Error (tanh)', 
                        'Train Error (ReLu)', 'Test Error (ReLu)'])

df


# In[ ]:




