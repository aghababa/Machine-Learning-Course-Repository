# Processing Data


```python
import numpy as np
import random
import time
import math
from termcolor import colored
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```

# Back Propagation


```python
from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t)) 
```


```python
def sigmoid1(z):
    return 1/(1+ math.exp(-z))

sigmoid = np.vectorize(sigmoid1)
```


```python
# Generating Gaussian random variable matrix:  
# np.random.normal(mean, standard deviation, shape)
#np.random.normal(0, 1, (2,3))
```


```python
class NeuralNetwork():
    
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        
        self.num_nodes_hid_layers_1 = num_nodes_hid_layers_1
        self.num_nodes_hid_layers_2 = num_nodes_hid_layers_2
        self.num_input_nodes = num_input_nodes
        self.num_output_nodes = num_output_nodes      
                
        self.weights_layer_1 = np.random.normal(0, 1, (self.num_nodes_hid_layers_1 -1, self.num_input_nodes))
        self.weights_layer_2 = np.random.normal(0, 1, (self.num_nodes_hid_layers_2 -1, self.num_nodes_hid_layers_1))
        self.weights_layer_3 = np.random.normal(0, 1, (self.num_output_nodes, self.num_nodes_hid_layers_2))


    def ForwardPass(self, x):

        x = x.reshape(-1,1)

        temp_1 = sigmoid(self.weights_layer_1 @ x)
        # temp_1 is values of z in layer 1, i.e. z_0^1, z_1^1, z_2^1

        temp_2 = sigmoid(self.weights_layer_2 @ np.concatenate((temp_1, np.array([[1]])), axis = 0))
        # temp_2 is values of z in layer 2, i.e. z_0^2, z_1^2, z_2^2
        
        temp_3 = self.weights_layer_3 @ np.concatenate((temp_2, np.array([[1]])), axis = 0)
        # temp_3 is values of what going to resige in sign function to give y 

        return(np.sign(temp_3))
        # returnes the y value
        
    
    def Backpropagation(self, x, y, gamma_0, d): # y=label(x)

        x = x.reshape(-1,1)
        
        temp_11 = sigmoid(self.weights_layer_1 @ x)
        
        temp_22 = sigmoid(self.weights_layer_2 @ np.concatenate((temp_11, np.array([[1]])), axis = 0))

        temp_33 = self.weights_layer_3 @ np.concatenate((temp_22, np.array([[1]])), axis = 0)
        
        temp = temp_33 - y
        self.grad_output = temp * (np.concatenate((temp_22, [[1]]), axis = 0)).T
    
        
        t = temp * self.weights_layer_3[:1, :-1] * temp_22.T*(1 - temp_22.T)
        self.grad_level_1 = (t * np.concatenate((temp_11, np.array([[1]])), axis = 0)).T
        
        Q = np.zeros((self.num_nodes_hid_layers_1 -1))
        for i in range(self.num_nodes_hid_layers_1 -1):
            Q[i] = (t @ self.weights_layer_2[:,i].T) * (temp_11.T * (1 - temp_11).T)[0,i]
        
        self.grad_level_0 = Q.reshape(-1,1) @ x.T
        
        
    def fun(self, x, y, gamma_0, d, number_of_iterations):
        
        self.Backpropagation(x, y, gamma_0, d)
        
        self.weights_layer_3 = self.weights_layer_3 - gamma(number_of_iterations, gamma_0, d) * self.grad_output
        self.weights_layer_2 = self.weights_layer_2 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_1
        self.weights_layer_1 = self.weights_layer_1 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_0 
        number_of_iterations = number_of_iterations + 1
        
        return(number_of_iterations)

```

# Debugging


```python
class NeuralNetwork_0(NeuralNetwork):
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        super().__init__(num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes)
        
        self.weights_layer_1 = np.array([[-2,-3,-1],[2,3,1]]) 
        self.weights_layer_2 = np.array([[-2,-3,-1],[2,3,1]])
        self.weights_layer_3 = np.array([[2, -1.5, -1]])
```


```python
N = NeuralNetwork_0(num_nodes_hid_layers_1 = 3, num_nodes_hid_layers_2 = 3, 
                  num_input_nodes = 3, num_output_nodes = 1)

N.fun(np.ones(3), np.ones(1), 0.02, 2, 1)
N.Backpropagation(np.ones(3), np.ones(1), 0.02, 2)

print(colored("Partial derivative of output layer: \n", 'blue'), N.grad_output, "\n")
print(colored("Partial derivative of layer 2: \n", 'blue'), N.grad_level_1, "\n")
print(colored("Partial derivative of layer 1: \n", 'blue'), N.grad_level_0, "\n")
```

    [34mPartial derivative of output layer: 
    [0m [[-0.05983344 -3.24316512 -3.30292799]] 
    
    [34mPartial derivative of layer 2: 
    [0m [[-0.00029069 -0.11728044 -0.11757118]
     [ 0.00020794  0.08389262  0.08410059]] 
    
    [34mPartial derivative of layer 1: 
    [0m [[0.00099479 0.00099479 0.00099479]
     [0.00149134 0.00149134 0.00149134]] 
    



```python

```
