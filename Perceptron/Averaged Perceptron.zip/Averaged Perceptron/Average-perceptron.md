# Processing Data


```python
import numpy as np
import random
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] == 0.0:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] == 0.0:
        test2[i][-1] = -1


test = np.array(test2)
```


```python
k = len(train)
n = len(test)
```

# Average Perceptron


```python
W = np.zeros(5)
r = 0.01
T = 10
a = np.zeros(5)

for t in range(T): 
    for i in range(k):
        if train[i][-1] * W.dot(train[i][:5]) <= 0:
            W = W + r * (train[i][-1] * train[i][:5])
            a = a + W

print(a)
```

    [  83.82       -111.71223448  -69.8838067   -68.2817363   -22.1753456 ]



```python
def sign(x):
    if x < 0:
        return -1
    else:
        return 1
```


```python
def prediction(x):
    return sign(a.dot(x))
```


```python
b = 0
for i in range(n):
    if test[i][-1] * prediction(test[i][:5]) < 0:
        b = b + 1
b, b/n
```




    (9, 0.018)




```python
#c = 0
#for i in range(k):
#    if train[i][-1] * prediction(train[i][:5]) < 0:
#        c = c + 1
#c, c/k
```


```python

```
