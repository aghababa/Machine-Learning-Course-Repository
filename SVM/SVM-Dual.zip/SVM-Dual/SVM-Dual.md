# Processing Data


```python
import numpy as np
import math
import pandas as pd 
from scipy import linalg as LA
from scipy.optimize import minimize
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

#for i in range(len(train1)):
#    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

#for i in range(len(test2)):
#    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```


```python
n = len(train)
m = len(test)
d = len(train[0]) - 1 # 4
```


```python
X = train[:,:-1]
Y = train[:,-1]
```

# Part (a): Dual SVM 


```python
def SVM_dual_obj(a):
    X = train[:,:-1]
    Z = np.diag(train[:,-1])
    return(0.5 * a @ ((Z@X) @ (Z@X).T) @ a.T - sum(a))
```


```python
#def SVM_dual_obj(x):
#    value = 0.5* sum(sum(train[i][-1]*train[j][-1]*x[i]*x[j]*(train[i][:-1].dot(train[j][:-1])) 
#for j in range(n)) for i in range(n)) - sum(x[i] for i in range(n))
#    
#    return value
```


```python
def constraint(a):
    Y = train[:,-1]
    return(a.dot(Y))
```


```python
def SVM_dual(C):
    bounds = tuple([(0,C) for i in range(n)])
    cons ={'type':'eq', 'fun': constraint}
    solution = minimize(SVM_dual_obj, np.zeros(n), method='SLSQP', bounds=bounds, constraints=cons)
    return(solution.x)
```


```python
a_min_list = []
C_list = [100/873, 500/873, 700/873]

for C in C_list:
    a_min = SVM_dual(C)
    a_min_list.append(a_min)

```


```python
#solution = minimize(SVM_dual, np.zeros(n), method='SLSQP', bounds=bounds, constraints=cons)
```


```python
#minimize(SVM_dual, np.zeros(n), method='trust-constr', bounds = bounds, constraints = cons)
```


```python
LA.norm(a_min_list[1])
sum(a_min_list[1]>1e-9)
```




    34




```python
#def jacobian(a):
#    A = np.zeros(n)
#    for i in range(n):
#        A[i] = 0.5 * sum(Y[i]*Y[j]*a[j]*(X[i].dot(X[j])) 
#                             for j in range(n)) + a[i]*(X[i].dot(X[i])) - 1
#    return(A)

#minimize(SVM_dual, np.zeros(n), method="L-BFGS-B", jac=jacobian, bounds=bounds)
```


```python
w_list = []

for i in range(len(C_list)):
    w_list.append(sum(a_min_list[i][j] * Y[j] * X[j] for j in range(n)))
    
w_list
```




    [array([-0.94292724, -0.65149171, -0.73372165, -0.04102168]),
     array([-1.56393678, -1.01405166, -1.18065023, -0.15651741]),
     array([-2.0426226 , -1.28013918, -1.51329009, -0.2483619 ])]




```python
b_1 = []
b_2 = []
b_3 = []
b_list = [b_1, b_2, b_3]

for i in range(len(C_list)):
    for j in range(n):
        if 1e-6 < a_min_list[i][j] < C- 1e-6: # a_min_list[i][j]>0: # C- 1e-6 > a_min_list[i][j] > 1e-6
            b_list[i].append(Y[j]- w_list[i].dot(X[j]))
```


```python
len(b_list[0]), len(b_list[1]), len(b_list[2])
```




    (45, 31, 6)




```python
b_ave_list = []
   
for i in range(3):
    b_ave_list.append(sum(b_list[i])/len(b_list[i]))

b_ave_list
```




    [1.07450321696107, 1.5123639929540702, 2.0449145348577336]



# Prediction and Errors


```python
def sgn(x):
    if x >=0:
        return 1
    else:
        return -1
```


```python
def predict(x, C):
    for j in range(len(C_list)):
        if C == C_list[j]:
            l = j

    return sgn((w_list[l].T @ x) + b_ave_list[l])
```


```python
label_train_predict = np.ones((len(C_list), n))

for j in range(len(C_list)):
    for i in range(n):
        label_train_predict[j][i] = predict(X[i], C_list[j])
            
```


```python
c = np.zeros(len(C_list))

for j in range(len(C_list)):
    for i in range(n):
        if label_train_predict[j][i] != Y[i]:
            #print(i)
            c[j] = c[j] + 1
print("Train error =", c/len(X))
print("Number of missclassified train examples:", list(c))
```

    Train error = [0.00917431 0.0103211  0.00917431]
    Number of missclassified train examples: [8.0, 9.0, 8.0]



```python
label_test_predict = np.ones((len(C_list), m))

for j in range(len(C_list)):
    for i in range(m):
        label_test_predict[j][i] = predict(test[i][:-1], C_list[j])
            
```


```python
e = np.zeros(len(C_list))

for j in range(len(C_list)):
    for i in range(m):
        if label_test_predict[j][i] != test[i][-1]:
            #print(i)
            e[j] = e[j] + 1
print("Train error =", e/len(test))
print("Number of missclassified test examples:", list(e))
```

    Train error = [0.01  0.014 0.01 ]
    Number of missclassified test examples: [5.0, 7.0, 5.0]



```python
w_list1 = np.around(w_list, decimals = 6)

Dic = {}
    
for i in range(len(C_list)): 
    Dic[i+1] = [C_list[i] * 873, c[i]/n, e[i]/m, b_ave_list[i], w_list1[i]]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['873*C','Train Error', 'Test Error', 'Bias', 'Learned Weight (rounded to 6 decimals)'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>873*C</th>
      <th>Train Error</th>
      <th>Test Error</th>
      <th>Bias</th>
      <th>Learned Weight (rounded to 6 decimals)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>100.0</td>
      <td>0.009174</td>
      <td>0.010</td>
      <td>1.074503</td>
      <td>[-0.942927, -0.651492, -0.733722, -0.041022]</td>
    </tr>
    <tr>
      <td>2</td>
      <td>500.0</td>
      <td>0.010321</td>
      <td>0.014</td>
      <td>1.512364</td>
      <td>[-1.563937, -1.014052, -1.18065, -0.156517]</td>
    </tr>
    <tr>
      <td>3</td>
      <td>700.0</td>
      <td>0.009174</td>
      <td>0.010</td>
      <td>2.044915</td>
      <td>[-2.042623, -1.280139, -1.51329, -0.248362]</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
