#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[1]:


import numpy as np
from numpy import linalg as LA
import random
import time


# In[2]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[3]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)


# # Primal SVM

# In[4]:


from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t))


# In[5]:


@jit(nopython = True)
def Objective_func(W, C, train):
    
    summ = (1/2) * W[:-1].dot(W[:-1])
    
    for i in range(len(train)):
        summ = summ + C * max(0, 1 - train[i][-1] * W.dot(train[i][:-1]))
    return(summ)


# In[7]:


def SVM(T, C, train, d, gamma_0, W_0): 
    
    WW = []
    Obj_func = [] # we will use Obj_func[1:] for plotting 
    Obj_func.append(0)
    count = 0
    N = len(train)
    V = np.array([1] * (len(W_0)-1)+[0])
    
    W = W_0
    for t in range(1, T+1): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(N): # for x in train: if x[-1]* ...
            if train[i][-1] * W.dot(train[i][:-1]) <= 1:
                W = W - gamma(t,gamma_0,d)*(V*W) + gamma(t,gamma_0,d)*C*N*(train[i][-1]*train[i][:-1])
            else: 
                W[:-1] = (1- gamma(t,gamma_0,d)) * W[:-1]
        
            WW.append(W)
            count = count +1 
            Obj_func.append(Objective_func(W, C, train))
    
    return(Obj_func[1:], W, WW, count)


# # Part (a)

# In[119]:


W_0 = np.zeros(5)
C = 1/873
T = 100
gamma_0 = 2
d = 1

Start_time = time.time()
Obj_func, W,WW, count = SVM(T, C, train, d, gamma_0, W_0)
#time = time.time() - Start_time
print(time.time() - Start_time)

print("Weight vector is:", W) 
print(count)
#print("Loss is:", Obj_func[1:])


# In[120]:


Obj_func[1:][:3]


# In[121]:


import matplotlib.pyplot as plt

plt.plot(Obj_func)
plt.show()


# # Train Error

# In[122]:


a = 0
m = len(train)
for i in range(m):
    if train[i][-1] * W.dot(train[i][:-1]) < 0:
        a = a + 1
a, a/m


# # Test Error

# In[123]:


b = 0
n = len(test)
for i in range(n):
    if test[i][-1] * W.dot(test[i][:-1]) < 0:
        b = b + 1
b, b/n


# # Different Values of C

# In[160]:


C_list = [100/873, 500/873, 700/873]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = 0.0001 
Obj_func = [0] * len(C_list)
W = [0] * len(C_list)
WW = [0] * len(C_list)
count = [0] * len(C_list)

for i in range(len(C_list)):
    
    Obj_func[i], W[i], WW[i], count[i] = SVM(T, C_list[i], train, d, gamma_0, W_0)


# In[161]:


for i in range(len(C_list)):
    plt.plot(Obj_func[i])
    plt.show()


# In[162]:


W


# # Train Error

# In[163]:


a = np.zeros(len(C_list))
m = len(train)

for j in range(len(C_list)):
    for i in range(m):
        if train[i][-1] * W[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)


# # Test Error

# In[164]:


b = np.zeros(len(C_list))
n = len(test)

for j in range(len(C_list)):
    for i in range(n):
        if test[i][-1] * W[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)


# # Representation in the form of Dataframe

# In[165]:


import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW[-1][872*t-1], 5), Obj_func[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head(10) 


# In[166]:


W_round = np.around(W, decimals = 5)

Dic = {}
    
for i in range(len(C_list)): 
    Dic[i+1] = [C_list[i] * 873, a[i]/m, b[i]/n, W_round[i]]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['873*C','Train Error', 'Test Error', 'Weights (rounded to 5 decimals)'])


# # Part (b)

# In[86]:


C_list = [100/873, 500/873, 700/873]
W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = gamma_0
Obj_func_b = [0] * len(C_list)
W_b = [0] * len(C_list)
WW_b = [0] * len(C_list)
count_b = [0] * len(C_list)

for i in range(len(C_list)):
    
    Obj_func_b[i], W_b[i], WW_b[i], count_b[i] = SVM(T, C_list[i], train, d, gamma_0, W_0)


# In[87]:


for i in range(len(C_list)):
    plt.plot(Obj_func_b[i])
    plt.show()


# In[88]:


W_b


# # Train Error

# In[89]:


a = np.zeros(len(C_list))
m = len(train)

for j in range(len(C_list)):
    for i in range(m):
        if train[i][-1] * W_b[j].dot(train[i][:-1]) < 0:
            a[j] = a[j] + 1

print("Number of training errors for each choice of C:", a, "\n") 
print("Train Error =", a/m)


# # Test Error

# In[90]:


b = np.zeros(len(C_list))
n = len(test)

for j in range(len(C_list)):
    for i in range(n):
        if test[i][-1] * W_b[j].dot(test[i][:-1]) < 0:
            b[j] = b[j] + 1

print("Number of test errors for each choice of C:", b, "\n") 
print("Test Error =", b/n)


# # Representation in the form of Dataframe

# In[91]:


import pandas as pd 

dic = {}
    
for t in range(1,T+1): 
    dic[t] = [t, np.around(WW_b[-1][872*t-1], 5), Obj_func_b[-1][872*t-1]]
    
df = pd.DataFrame.from_dict(dic, orient='index', columns=['T','Weights (rounded to 5 decimals)', 'Loss'])

df.head(10) 


# In[92]:


W_round_b = np.around(W_b, decimals = 5)

Dic = {}
    
for i in range(len(C_list)): 
    Dic[i+1] = [C_list[i] * 873, a[i]/m, b[i]/n, W_round_b[i]]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['873*C','Train Error', 'Test Error', 'Weights (rounded to 5 decimals)'])


# # Part (c)

# In[167]:


LA.norm(W[0]-W_b[0]), LA.norm(W[1]-W_b[1]), LA.norm(W[2]-W_b[2])


# In[ ]:




