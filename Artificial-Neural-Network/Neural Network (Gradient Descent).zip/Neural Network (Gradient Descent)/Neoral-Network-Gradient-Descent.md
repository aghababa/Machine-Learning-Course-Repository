# Processing Data


```python
import numpy as np
import random
import time
import math
import pandas as pd 
from scipy import linalg as LA
```


```python
def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data
```


```python
train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(4,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(4,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)
```


```python
n = len(train)
m = len(test)
```


```python
c1 = 0
for i in range(n):
    if train[i][-1] > 0:
        c1 = c1 + 1
c1
```




    389



# Back Propagation


```python
from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t)) 
```


```python
def sigmoid1(z):
    return 1/(1+ math.exp(-z))

sigmoid = np.vectorize(sigmoid1)
```


```python
# Generating a Gaussian random variable matrix  
# np.random.normal(mean, standard deviation, shape)
#np.random.normal(0, 1, (2,3))
```


```python
class NeuralNetwork():
    
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        
        self.num_nodes_hid_layers_1 = num_nodes_hid_layers_1
        self.num_nodes_hid_layers_2 = num_nodes_hid_layers_2
        self.num_input_nodes = num_input_nodes
        self.num_output_nodes = num_output_nodes      
                
        self.weights_layer_1 = np.random.normal(0, 1, (self.num_nodes_hid_layers_1 -1, self.num_input_nodes))
        self.weights_layer_2 = np.random.normal(0, 1, (self.num_nodes_hid_layers_2 -1, self.num_nodes_hid_layers_1))
        self.weights_layer_3 = np.random.normal(0, 1, (self.num_output_nodes, self.num_nodes_hid_layers_2))


    def ForwardPass(self, x):

        x = x.reshape(-1,1)

        self.temp_1 = sigmoid(self.weights_layer_1 @ x)
        # temp_1 is values of z in layer 1, i.e. z_0^1, z_1^1, z_2^1

        self.temp_2 = sigmoid(self.weights_layer_2 @ np.concatenate((self.temp_1, np.array([[1]])), axis = 0))
        # temp_2 is values of z in layer 2, i.e. z_0^2, z_1^2, z_2^2
        
        self.temp_3 = self.weights_layer_3 @ np.concatenate((self.temp_2, np.array([[1]])), axis = 0)
        # temp_3 is values of what going to resige in sign function to give y 

        return(np.sign(self.temp_3))
        # returnes the y value
        
    
    def Backpropagation(self, x, y, gamma_0, d): # y=label(x)

        x = x.reshape(-1,1)
        
        temp_11 = sigmoid(self.weights_layer_1 @ x)
        
        temp_22 = sigmoid(self.weights_layer_2 @ np.concatenate((temp_11, np.array([[1]])), axis = 0))

        temp_33 = self.weights_layer_3 @ np.concatenate((temp_22, np.array([[1]])), axis = 0)
        
        temp = temp_33 - y
        self.grad_output = temp * (np.concatenate((temp_22, [[1]]), axis = 0)).T
    
        
        t = temp * self.weights_layer_3[:1, :-1] * temp_22.T*(1 - temp_22.T)
        self.grad_level_1 = (t * np.concatenate((temp_11, np.array([[1]])), axis = 0)).T
        
        Q = np.zeros((self.num_nodes_hid_layers_1 -1))
        for i in range(self.num_nodes_hid_layers_1 -1):
            Q[i] = (t @ self.weights_layer_2[:,i].T) * (temp_11.T * (1 - temp_11).T)[0,i]
        
        self.grad_level_0 = Q.reshape(-1,1) @ x.T
        
        return(self.grad_level_0, self.grad_level_1, self.grad_output)
    
    def fun(self, x, y, gamma_0, d, number_of_iterations):
        self.Backpropagation(x, y, gamma_0, d)
        
        self.weights_layer_3 = self.weights_layer_3 - gamma(number_of_iterations, gamma_0, d) * self.grad_output
        self.weights_layer_2 = self.weights_layer_2 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_1
        self.weights_layer_1 = self.weights_layer_1 - gamma(number_of_iterations, gamma_0, d) * self.grad_level_0 
        number_of_iterations = number_of_iterations + 1
        
        return(number_of_iterations)

```

# Stochastic Gradient Descent


```python
start = time.time()
width_list = [5, 10, 25, 50, 100]
T = 20
gamma_0 = 0.02
d = 2
w_list = []
N = [0] * len(width_list)

for k in range(len(width_list)):
    start1 = time.time()
    N[k] = NeuralNetwork(num_nodes_hid_layers_1 = width_list[k], num_nodes_hid_layers_2 = 
                         width_list[k], num_input_nodes = 5, num_output_nodes = 1)

    w = np.array([N[k].weights_layer_1, N[k].weights_layer_2, N[k].weights_layer_3])

    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(n):
            N[k].fun(train[i][:-1], train[i][-1], gamma_0, d, 1)
            w = w - np.array([[gamma(t, gamma_0, d)]]) * N[k].Backpropagation(
                train[i][:-1], train[i][-1], gamma_0, d)
            
    
    print(time.time() - start1)
    w_list.append(w)

print(time.time() - start)
```

    15.62557601928711
    18.2119140625
    31.668313026428223
    58.996981143951416
    105.35071110725403
    229.85526585578918


# Train Error


```python
a = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(n):
        if train[i][-1] * N[k].ForwardPass(train[i][:-1]) < 0:
            a[k] = a[k] + 1
a, a/n
```




    (array([0., 0., 0., 0., 0.]), array([0., 0., 0., 0., 0.]))



# Test Error


```python
b = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(m):
        if test[i][-1] * N[k].ForwardPass(test[i][:-1]) < 0:
            b[k] = b[k] + 1
b, b/m
```




    (array([0., 0., 0., 0., 0.]), array([0., 0., 0., 0., 0.]))




```python
weight = [0] * len(width_list)

for k in range(len(width_list)):
    weight[k] = w_list[k][-1][-1][-1]
```

# Presentation of errors on dataframe


```python
T = 1
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.010321</td>
      <td>0.012</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.001147</td>
      <td>0.002</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.004587</td>
      <td>0.006</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.004587</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.019495</td>
      <td>0.012</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 5
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.006881</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.012615</td>
      <td>0.014</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.002294</td>
      <td>0.004</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.000000</td>
      <td>0.002</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.000000</td>
      <td>0.002</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 10
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.006881</td>
      <td>0.018</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.000000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.000000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.000000</td>
      <td>0.002</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.000000</td>
      <td>0.000</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 20
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a[i]/n, b[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



# Initializing with 0 weights


```python
class NeuralNetwork_0(NeuralNetwork):
    def __init__(self, num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes):
        super().__init__(num_nodes_hid_layers_1, num_nodes_hid_layers_2,
                num_input_nodes, num_output_nodes)
        
        self.weights_layer_1 = np.zeros((self.num_nodes_hid_layers_1 -1, self.num_input_nodes))
        self.weights_layer_2 = np.zeros((self.num_nodes_hid_layers_2 -1, self.num_nodes_hid_layers_1))
        self.weights_layer_3 = np.zeros((self.num_output_nodes, self.num_nodes_hid_layers_2))

```


```python
start = time.time()
width_list = [5, 10, 25, 50, 100]
T = 1
gamma_0 = 0.02
d = 2
w_0_list = []
N_0 = [0] * len(width_list)

for k in range(len(width_list)):
    start1 = time.time()
    N_0[k] = NeuralNetwork_0(num_nodes_hid_layers_1 = width_list[k], num_nodes_hid_layers_2 = 
                         width_list[k], num_input_nodes = 5, num_output_nodes = 1)

    w = np.array([N_0[k].weights_layer_1, N_0[k].weights_layer_2, N_0[k].weights_layer_3])

    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(n):
            N_0[k].fun_0(train[i][:-1], train[i][-1], gamma_0, d, 1)
            w = w - np.array([[gamma(t, gamma_0, d)]]) * N_0[k].Backpropagation_0(train[i][:-1], train[i][-1], gamma_0, d)
    
    print(time.time() - start1)
    w_0_list.append(w)

print(time.time() - start)
```

    0.7497222423553467
    0.9431250095367432
    1.5490000247955322
    2.7580230236053467
    5.718754053115845
    11.720747709274292



```python
a0 = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(n):
        if train[i][-1] * N_0[k].ForwardPass_0(train[i][:-1]) < 0:
            a0[k] = a0[k] + 1
a0, a0/n
```




    (array([389., 389., 389., 389., 483.]),
     array([0.44610092, 0.44610092, 0.44610092, 0.44610092, 0.55389908]))




```python
b0 = np.zeros(len(width_list))

for k in range(len(width_list)):
    for i in range(m):
        if test[i][-1] * N_0[k].ForwardPass_0(test[i][:-1]) < 0:
            b0[k] = b0[k] + 1
b0, b0/m
```




    (array([221., 221., 221., 221., 279.]),
     array([0.442, 0.442, 0.442, 0.442, 0.558]))




```python
T = 1
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.446101</td>
      <td>0.442</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.446101</td>
      <td>0.442</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.446101</td>
      <td>0.442</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.446101</td>
      <td>0.442</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.553899</td>
      <td>0.558</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 5
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.446101</td>
      <td>0.442</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.364679</td>
      <td>0.352</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.034404</td>
      <td>0.028</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.032110</td>
      <td>0.032</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.032110</td>
      <td>0.032</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 10
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.009174</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.012615</td>
      <td>0.012</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.011468</td>
      <td>0.014</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.017202</td>
      <td>0.016</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.017202</td>
      <td>0.016</td>
    </tr>
  </tbody>
</table>
</div>




```python
T = 20
Dic = {}
    
for i in range(len(width_list)): 
    Dic[i+1] = [width_list[i], a0[i]/n, b0[i]/m]
    
pd.DataFrame.from_dict(Dic, orient='index', columns=['Width','Train Error', 'Test Error'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Width</th>
      <th>Train Error</th>
      <th>Test Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>5</td>
      <td>0.009174</td>
      <td>0.010</td>
    </tr>
    <tr>
      <td>2</td>
      <td>10</td>
      <td>0.009174</td>
      <td>0.012</td>
    </tr>
    <tr>
      <td>3</td>
      <td>25</td>
      <td>0.017202</td>
      <td>0.016</td>
    </tr>
    <tr>
      <td>4</td>
      <td>50</td>
      <td>0.018349</td>
      <td>0.016</td>
    </tr>
    <tr>
      <td>5</td>
      <td>100</td>
      <td>0.017202</td>
      <td>0.016</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
