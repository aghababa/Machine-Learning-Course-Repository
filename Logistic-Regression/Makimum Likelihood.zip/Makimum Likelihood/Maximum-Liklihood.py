#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[1]:


import numpy as np
import random
import time
import math


# In[2]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[3]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)


# # Maximum Likelihood

# In[4]:


from numba import jit
@jit(nopython = True)
def gamma(t, gamma_0, d):
    return (gamma_0/(1+ (gamma_0/d)*t))


# In[5]:


@jit(nopython = True)
def Objective_func(W, train):
    
    summ = 0
    for i in range(len(train)):
        if -train[i][-1] * W.dot(train[i][:-1]) > 200:
            summ = summ + np.log(1 + math.exp(200))
        else: 
            summ = summ + np.log(1 + math.exp(-train[i][-1] * W.dot(train[i][:-1])))
    return(summ)


# In[6]:


@jit(nopython = True)
def Objective_func1(W, x, y, N):
    
    if - y * W.dot(x) > 200: # 709
        L = N * np.log(1 + math.exp(200))

    else: 
        L = N * np.log(1 + math.exp(- y * W.dot(x)))
    
    return(L)


# In[7]:


def sigmoid(z):
    if z < -200:
        return 0
    else:
        return 1/(1+ math.exp(-z))

#sigmoid = np.vectorize(sigmoid)


# In[8]:


def Maximum_Likelihood(T, train, d, gamma_0, W_0): 
    
    WW = []
    Obj_func = []  
    N = len(train)
    
    W = W_0
    for t in range(T): 
        train_list = list(train)
        random.shuffle(train_list)
        train = np.array(train_list)
        for i in range(N): 
            grad_SGD = - N * train[i][-1] * (1 - sigmoid(train[i][-1] * W.dot(train[i][:-1]))) * train[i][:-1]
            W = W - gamma(t,gamma_0,d) * grad_SGD

            WW.append(W)
            Obj_func.append(Objective_func(W, train))
            #Obj_func.append(Objective_func1(W, train[i][:-1], train[i][-1],N))
    
    return(Obj_func, W, WW)


# In[9]:


W_0 = np.zeros(5)
T = 100
gamma_0 = 0.001
d = 0.002

Start_time = time.time()
Obj_func, W , WW = Maximum_Likelihood(T, train, d, gamma_0, W_0)
print(time.time() - Start_time)

print("Weight vector is:", W) 
print("Loss is:", Obj_func[-5:-1])


# In[10]:


import matplotlib.pyplot as plt

plt.plot(Obj_func)
plt.show()


# # Train Error

# In[11]:


a = 0
m = len(train)
for i in range(m):
    if train[i][-1] * W.dot(train[i][:-1]) < 0:
        a = a + 1
a, a/m


# # Test Error

# In[12]:


b = 0
n = len(test)
for i in range(n):
    if test[i][-1] * W.dot(test[i][:-1]) < 0:
        b = b + 1
b, b/n


# In[ ]:




