#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[1]:


import numpy as np
import random


# In[2]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[3]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] == 0.0:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] == 0.0:
        test2[i][-1] = -1


test = np.array(test2)


# In[4]:


k = len(train)
n = len(test)


# # Voted Perceptron

# In[5]:


Weights = []
C = []
W = np.zeros(5)
r = 1
T = 10
m = 0
Weights.append(W)
C.append(1)

for t in range(T): 
    for i in range(k):
        if train[i][-1] * W.dot(train[i][:5]) <= 0:
            W = W + r * (train[i][-1] * train[i][:5])
            Weights.append(W)
            m = m + 1
            C.append(1)
        else:
            C[-1] = C[-1] + 1

print(Weights, C)


# In[6]:


def sign(x):
    if x < 0:
        return -1
    else:
        return 1


# In[7]:


L = len(Weights)

def prediction(x):
    summ = 0
    for i in range(L):
        summ = summ + C[i] * sign(Weights[i].dot(x))
    return sign(summ)
L


# In[30]:


#a = 0
#for i in range(k):
#    if train[i][-1] * prediction(train[i][:5]) < 0:
#        a = a + 1
#a, a/k


# In[9]:


a = 0
for i in range(n):
    if test[i][-1] * prediction(test[i][:5]) < 0:
        a = a + 1
a, a/n


# In[10]:


V = np.array(Weights)
b = 0 

for i in range(L):
    for j in range(i+1,L):
        if sum((V[i]-V[j])**2) == 0:
            b = b + 1
b


# In[11]:


Weights[-20:]


# In[12]:


print(C[-20:])


# In[ ]:




