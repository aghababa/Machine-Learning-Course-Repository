#!/usr/bin/env python
# coding: utf-8

# # Processing Data

# In[45]:


import numpy as np
import random


# In[46]:


def to_float(data):
    for x in data:
        for i in range(len(data[0])):
            x[i] = float(x[i])
    return data


# In[47]:


train1 = []

with open("bank-note/train.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        train1.append(item) #([1]+ item)
        
train2 = to_float(train1)        

for i in range(len(train1)):
    train1[i].insert(0,1)


test1 = []

with open("bank-note/test.csv", "r") as f:
    for line in f:
        item = line.strip().split(",")
        test1.append(item)
        
test2 = to_float(test1)

for i in range(len(test2)):
    test2[i].insert(0,1)
    

for i in range(len(train2)):
    train2[i] = np.array(train2[i])
    if train2[i][-1] < 0.5:
        train2[i][-1] = -1
    

train = np.array(train2)



for i in range(len(test2)):
    test2[i] = np.array(test2[i])
    if test2[i][-1] < 0.5:
        test2[i][-1] = -1


test = np.array(test2)


# In[48]:


m = len(train)
n = len(test)


# # Standard Perceptron

# In[49]:


W = np.zeros(5)
r = 0.1
c = 1
T = 10

for t in range(T): 
    random.shuffle(train)
    for i in range(m):
        if train[i][-1] * W.dot(train[i][:-1]) <= 0:
            W = W + r * (train[i][-1] * train[i][:-1])
            c = c + 1
print(W, c)


# # Average error on test and train data

# In[50]:


a = 0
for i in range(n):
    if test[i][-1] * W.dot(test[i][:-1]) < 0:
        a = a + 1
a, a/n


# In[53]:


#b = 0
#for i in range(m):
#    if train[i][-1] * W.dot(train[i][:-1]) < 0:
#        b = b + 1
#b, b/m


# In[35]:





# In[ ]:





# In[ ]:





# In[ ]:




